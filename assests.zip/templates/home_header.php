<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Citizen Participation</title>
    <link rel="stylesheet" href="assests/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script>
        function toggleMenu() {
            document.querySelector('.navbar ul').classList.toggle('active');
        }
    </script>
</head>
<body>
    <header>
        <div class="logo">
            <h1>Citizen Participation</h1>
        </div>
        <div class="nav-toggle" onclick="toggleMenu()">☰</div>
    </header>

    <nav class="navbar">
        <ul>
            <li><a href="./home.php">Home</a></li>
            <li><a href="./feedback.php">Feedback</a></li>
            <li><a href="polls.html">Polls</a></li>
            <li><a href="./projects.php">Projects</a></li>
            <li><a href="meetings.html">Town Halls</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </nav>

    <div class="container">
        <h2>Welcome to the Citizen Participation Platform</h2>
        <p>Engage with your community, share feedback, vote on policies, and track local projects.</p>
        <button>Get Started</button>
    </div>
</body>
</html>
