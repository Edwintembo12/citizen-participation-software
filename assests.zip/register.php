<style>
    body {
    font-family: 'Arial', sans-serif;
    background: linear-gradient(to bottom, #ff7e5f, #feb47b);
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    color: #fff;
}

.register-container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    max-width: 400px;
}

.register-card {
    background: #fff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    text-align: center;
    width: 100%;
    color: #333;
}

h2 {
    margin-bottom: 20px;
    color: #444;
}

.form-group {
    margin-bottom: 20px;
    width: 100%;
}

input[type="text"], input[type="email"], input[type="password"], select {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 5px;
    background: #f9f9f9;
}

input:focus, select:focus {
    border-color: #ff7e5f;
    outline: none;
}

select {
    appearance: none;
    background: #f9f9f9 url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4 5"><path fill="%23333" d="M2 0L0 2h4z"/></svg>') no-repeat right 10px center;
    background-size: 10px;
}

.btn-register {
    background: #ff7e5f;
    color: #fff;
    font-size: 16px;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    width: 100%;
    transition: background 0.3s ease;
}

.btn-register:hover {
    background: #feb47b;
}

.error, .success {
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 5px;
    font-size: 14px;
}

.error {
    background: #ff4d4f;
    color: #fff;
}

.success {
    background: #4caf50;
    color: #fff;
}

a {
    color: #ff7e5f;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

</style>
<?php include('db_connection.php'); ?>

<div class="register-container">
    <div class="register-card">
        <h2>Register</h2>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $first_name = $conn->real_escape_string($_POST['first_name']);
            $last_name = $conn->real_escape_string($_POST['last_name']);
            $email = $conn->real_escape_string($_POST['email']);
            $password = $_POST['password'];
            $role = $conn->real_escape_string($_POST['role']);
            $registration_date = date('Y-m-d H:i:s'); // Capture the current date and time

            // Hash the password
            $password_hash = password_hash($password, PASSWORD_BCRYPT);

            // Insert the user data into the database
            $sql = "INSERT INTO users (first_name, last_name, email, password_hash, role, registration_date)
                    VALUES ('$first_name', '$last_name', '$email', '$password_hash', '$role', '$registration_date')";

            if ($conn->query($sql) === TRUE) {
                echo "<div class='success'>Registration successful! <a href='login.php'>Login now</a></div>";
            } else {
                echo "<div class='error'>Error: " . $conn->error . "</div>";
            }
        }
        ?>
        <form action="register.php" method="post">
            <div class="form-group">
                <input type="text" name="first_name" placeholder="First Name" required>
            </div>
            <div class="form-group">
                <input type="text" name="last_name" placeholder="Last Name" required>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <select name="role" required>
                    <option value="" disabled selected>Select Role</option>
                    <option value="citizen">Citizen</option>
                    <option value="official">Official</option>
                    <option value="moderator">Moderator</option>
                </select>
            </div>
            <button type="submit" class="btn-register">Register</button>
        </form>
    </div>
</div>

<?php include('templates/footer.php'); ?>
