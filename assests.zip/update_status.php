<?php
session_start();
include 'db_connection.php';

// Ensure only admins can perform this action
if ($_SESSION['role'] !== 'admin') {
    echo "Unauthorized access.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $project_id = $_POST['project_id'];
    $status = $_POST['status'];

    // Update query
    $query = "UPDATE projects SET status = ? WHERE project_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $status, $project_id);

    if ($stmt->execute()) {
        echo "Status updated successfully.";
    } else {
        echo "Error updating status: " . $conn->error;
    }

    $stmt->close();
    $conn->close();

    // Redirect back to the projects page
    header("Location: view_projects.php");
    exit();
}
?>
