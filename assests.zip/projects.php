<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Project</title>
    <link rel="stylesheet" href="assets/styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #3e8ef7;
            padding: 10px 20px;
            color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        header .logo {
            display: flex;
            align-items: center;
        }

        header .logo img {
            height: 40px;
            margin-right: 10px;
        }

        header h1 {
            font-size: 1.5em;
            margin: 0;
        }

        .nav-toggle {
            font-size: 1.5em;
            cursor: pointer;
            display: none;
        }

        .navbar {
            background-color: #357bd1;
            padding: 10px 20px;
        }

        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .navbar ul li {
            margin: 0 10px;
        }

        .navbar ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 1em;
            padding: 8px 12px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .navbar ul li a:hover {
            background-color: #2a5ba0;
        }

        .container {
            max-width: 900px;
            margin: 30px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 1.8em;
            color: #3e8ef7;
            margin-bottom: 20px;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
        }

        input, select, textarea {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            width: 100%;
        }

        button {
            background-color: #3e8ef7;
            color: #fff;
            border: none;
            padding: 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1em;
            transition: background-color 0.3s, transform 0.2s;
        }

        button:hover {
            background-color: #357bd1;
            transform: scale(1.05);
        }

        @media (max-width: 768px) {
            .nav-toggle {
                display: block;
            }

            .navbar ul {
                flex-direction: column;
                display: none;
            }

            .navbar ul.active {
                display: flex;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <h1>Citizen Participation</h1>
        </div>
        <div class="nav-toggle" onclick="toggleMenu()">☰</div>
    </header>

  
    <nav class="navbar">
        <ul>
                     <li><a href="./home.php">Home</a></li>
            <li><a href="feedback.php">Feedback</a></li>
            <li><a href="issues.php">Report An Issue</a></li>
            <li><a href="reported_issue.php">Complaints</a></li>
            <li><a href="suggestions.php">Polls</a></li>
            <li><a href="projects.php">Projects</a></li>
            <li><a href="https://meet.google.com/">Town Halls</a></li>
        </ul>
     
    </nav>

    <div class="container">
        <h2>Welcome to the Citizen Participation Platform</h2>
        <a href="view_projects.php" style="display: inline-block; text-decoration: none; background-color: #3e8ef7; color: #fff; border: none; padding: 14px 24px; border-radius: 8px; cursor: pointer; font-size: 1em; margin-top: 12px; transition: background-color 0.3s, transform 0.2s;">View Projects</a>
    </div>

    <div class="container">
        <?php
        include('db_connection.php'); 
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $title = $_POST['title'];
            $description = $_POST['description'];
            $start_date = $_POST['start_date'];
            $end_date = $_POST['end_date'];
            $status = $_POST['status'];
            $created_by = $_POST['created_by'];
            $query = "INSERT INTO projects (title, description, start_date, end_date, status, created_by) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssssss", $title, $description, $start_date, $end_date, $status, $created_by);

            if ($stmt->execute()) {
                echo "<p style='color: green;'>Project added successfully.</p>";
            } else {
                echo "<p style='color: red;'>Error adding project: " . $conn->error . "</p>";
            }

            $stmt->close();
            $conn->close();
        }
        ?>
        <form action="projects.php" method="post">
            <label for="title">Project Title:</label>
            <input type="text" id="title" name="title" placeholder="Enter project title" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description" placeholder="Enter project description" required></textarea>

            <label for="start_date">Start Date:</label>
            <input type="date" id="start_date" name="start_date" required>

            <label for="end_date">End Date:</label>
            <input type="date" id="end_date" name="end_date" required>

            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="Upcoming">Upcoming</option>
                <option value="Ongoing">Ongoing</option>
                <option value="Completed">Completed</option>
            </select>

            <label for="created_by">Created By:</label>
            <input type="text" id="created_by" name="created_by" placeholder="Enter your name" required>

            <button type="submit">Add Project</button>
        </form>
    </div>

    <script>
        function toggleMenu() {
            const navbar = document.querySelector('.navbar ul');
            navbar.classList.toggle('active');
        }
    </script>
</body>
</html>
