<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Citizen Participation</title>
    <link rel="stylesheet" href="assets/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script>
        function toggleMenu() {
            document.querySelector('.navbar ul').classList.toggle('active');
        }
    </script>
    <style>
        /* General styles */
        body, h1, h2, h3, p {
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #4a90e2, #56c2d6);
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 0 20px;
        }

        .header {
            text-align: center;
            padding: 20px;
            background: #fff;
            border-radius: 12px;
            margin-top: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .header h1 {
            color: #4a90e2;
        }

        .header p {
            font-size: 18px;
            color: #555;
        }

        /* Navbar styles */
        .navbar {
            background: #4a90e2;
            width: 100%;
            display: flex;
            justify-content: center;
            padding: 10px 0;
            border-radius: 8px;
            margin: 20px 0;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .navbar ul {
            list-style: none;
            display: flex;
            gap: 20px;
            padding: 0;
            margin: 0;
        }

        .navbar li {
            display: inline;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            padding: 10px 15px;
            border-radius: 6px;
            transition: background-color 0.3s, transform 0.3s;
        }

        .navbar a:hover {
            background: #357bd1;
            transform: scale(1.05);
        }

        /* Container styles */
        .container {
            background: #fff;
            width: 100%;
            max-width: 1100px;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
            margin: 20px 0;
            text-align: center;
        }

        .intro {
            margin-bottom: 30px;
        }

        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .feature {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            text-align: center;
        }

        .feature:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }

        .feature h3 {
            color: #4a90e2;
            margin-bottom: 10px;
        }

        .feature p {
            margin-bottom: 15px;
            color: #555;
        }

        .button {
            background: linear-gradient(135deg, #4a90e2, #56c2d6);
            color: #fff;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 16px;
            transition: background 0.3s, transform 0.3s;
        }

        .button:hover {
            background: linear-gradient(135deg, #357bd1, #4a90e2);
            transform: scale(1.05);
        }

        /* Footer styles */
        .footer {
            margin-top: 30px;
            text-align: center;
            padding: 15px;
            background: #4a90e2;
            color: #fff;
            width: 100%;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <header class="header">
        <h1>Citizen Participation</h1>
        <p>Empowering communities through engagement and collaboration.</p>
    </header>

    <nav class="navbar">
        <ul>
            <li><a href="./home.php">Home</a></li>
            <li><a href="feedback.php">Feedback</a></li>
            <li><a href="issues.php">Report An Issue</a></li>
            <li><a href="reported_issue.php">Complaints</a></li>
            <li><a href="suggestions.php">Polls</a></li>
            <li><a href="projects.php">Projects</a></li>
            <li><a href="https://meet.google.com/">Town Halls</a></li>
        </ul>
    </nav>

    <div class="container">
        <section class="intro">
            <h2>Welcome to the Citizen Participation Platform</h2>
            <p>Empowering you to share feedback, vote on policies, participate in virtual town halls, and stay updated on local projects.</p>
        </section>

        <section class="features">
            <div class="feature">
                <h3>Share Feedback</h3>
                <p>Submit suggestions and engage with the community through comments and votes.</p>
                <a href="feedback.php" class="button">Submit Feedback</a>
            </div>
            <div class="feature">
                <h3>Vote on Polls</h3>
                <p>Make your voice heard on policies and community decisions through interactive polls.</p>
                <a href="polls.html" class="button">Vote Now</a>
            </div>
            <div class="feature">
                <h3>Track Projects</h3>
                <p>Stay informed on local initiatives, track their progress, and see how they impact your community.</p>
                <a href="projects.html" class="button">Explore Projects</a>
            </div>
            <div class="feature">
                <h3>Join Town Halls</h3>
                <p>Participate in virtual meetings with officials to discuss community topics and issues.</p>
                <a href="meetings.html" class="button">Join a Meeting</a>
            </div>
        </section>
    </div>

    <footer class="footer">
        <p>&copy; 2024 Citizen Participation Platform. All rights reserved.</p>
    </footer>
</body>
</html>
