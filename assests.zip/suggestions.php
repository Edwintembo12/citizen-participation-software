<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Suggestions</title>
    <link rel="stylesheet" href="assets/styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
            color: #333;
        }

        header {
            background-color: #3e8ef7;
            color: #fff;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .logo img {
            height: 40px;
            margin-right: 1rem;
        }

        .logo h1 {
            display: inline;
            font-size: 1.5rem;
        }
 
        .nav-toggle {
            font-size: 1.5rem;
            cursor: pointer;
            display: none;
        }

        nav.navbar {
            background-color: #3e8ef7;
            padding: 0.5rem 1rem;
        }

        nav.navbar ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            flex-wrap: wrap;
        }

        nav.navbar li {
            margin: 0 1rem;
        }

        nav.navbar a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        nav.navbar a:hover {
            color: #ffd700;
        }

        .container {
            margin: 2rem auto;
            padding: 1rem;
            max-width: 1000px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .container h2 {
            margin-top: 0;
            color: #0047ab;
        }

        .container p {
            line-height: 1.6;
        }

        .button {
            display: inline-block;
            background-color: #0047ab;
            color: #fff;
            padding: 0.5rem 1rem;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #003580;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        table thead {
            background-color: #3e8ef7;
            color: #fff;
        }

        table th, table td {
            padding: 1rem;
            text-align: left;
            border: 1px solid #ddd;
        }

        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        form {
            display: inline;
        }

        button {
            background-color: #0047ab;
            color: #fff;
            border: none;
            padding: 0.5rem 1rem;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #003580;
        }

        @media (max-width: 768px) {
            .nav-toggle {
                display: block;
            }

            nav.navbar ul {
                display: none;
                flex-direction: column;
                width: 100%;
                background-color: #003580;
            }

            nav.navbar ul.show {
                display: flex;
            }

            nav.navbar li {
                margin: 0.5rem 0;
                text-align: center;
            }
        }
    </style>
    <script>
        function toggleMenu() {
            const navbar = document.querySelector('nav.navbar ul');
            navbar.classList.toggle('show');
        }
    </script>
</head>
<body>
    <header>
        <div class="logo">
            <h1>Citizen Participation</h1>
        </div>
        <div class="nav-toggle" onclick="toggleMenu()">☰</div>
    </header>

  
    <nav class="navbar">
        <ul>
                     <li><a href="./home.php">Home</a></li>
            <li><a href="feedback.php">Feedback</a></li>
            <li><a href="issues.php">Report An Issue</a></li>
            <li><a href="reported_issue.php">Complaints</a></li>
            <li><a href="suggestions.php">Polls</a></li>
            <li><a href="projects.php">Projects</a></li>
            <li><a href="https://meet.google.com/">Town Halls</a></li>
        </ul>
     
    </nav>

    <div class="container">
        <h2>Welcome to the Citizen Participation Platform</h2>
        <p>Engage with your community, share feedback, vote on policies, and track local projects.</p>
        <a href="feedback.php" class="button">Create Feedback</a>
    </div>

    <div class="container">
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Upvotes</th>
                    <th>Downvotes</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'db_connection.php';
                $query = "SELECT * FROM feedback ORDER BY submission_date DESC";
                $result = $conn->query($query);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['title']}</td>
                                <td>{$row['description']}</td>
                                <td>{$row['upvotes']}</td>
                                <td>{$row['downvotes']}</td>
                                <td>{$row['status']}</td>
                                <td>
                                    <form action='vote.php' method='post'>
                                        <input type='hidden' name='suggestion_id' value='{$row['suggestion_id']}'>
                                        <button type='submit' name='vote' value='upvote'>Upvote</button>
                                    </form>
                                    <form action='vote.php' method='post'>
                                        <input type='hidden' name='suggestion_id' value='{$row['suggestion_id']}'>
                                        <button type='submit' name='vote' value='downvote'>Downvote</button>
                                    </form>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No suggestions found.</td></tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
