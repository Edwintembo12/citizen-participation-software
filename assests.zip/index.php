<?php include('db_connection.php'); ?>
<style type="text/css">
    body {
    font-family: 'Arial', sans-serif;
    background: linear-gradient(to bottom, #6a11cb, #2575fc);
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    color: #fff;
}

.login-container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    max-width: 400px;
}

.login-card {
    background: #fff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    text-align: center;
    width: 100%;
    color: #333;
}

h2 {
    margin-bottom: 20px;
    color: #444;
}

.form-group {
    margin-bottom: 20px;
    width: 100%;
}

input[type="email"], input[type="password"] {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 5px;
    background: #f9f9f9;
}

input:focus {
    border-color: #2575fc;
    outline: none;
}

.btn-login {
    background: #2575fc;
    color: #fff;
    font-size: 16px;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    width: 100%;
}

.btn-login:hover {
    background: #6a11cb;
}

.error {
    background: #ff4d4f;
    color: #fff;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 5px;
}

.success {
    background: #4caf50;
    color: #fff;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 5px;
}

.login-footer {
    margin-top: 10px;
    font-size: 14px;
    color: #777;
}

.login-footer a {
    color: #2575fc;
    text-decoration: none;
}

.login-footer a:hover {
    text-decoration: underline;
}

</style>
<div class="login-container">
    <div class="login-card">
        <h2>Login</h2>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $email = $conn->real_escape_string($_POST['email']);
            $password = $_POST['password'];

            // Fetch the user's data from the database
            $sql = "SELECT * FROM users WHERE email = '$email'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                // Verify the password
                if (password_verify($password, $row['password_hash'])) {
                    echo "<div class='success'>Login successful! Welcome, " . $row['first_name'] . " " . $row['last_name'] . ".</div>";
                    // Redirect or start a session as needed
                    session_start();
                    $_SESSION['user_id'] = $row['user_id'];
                    header("Location: home.php");
                } else {
                    echo "<div class='error'>Invalid password. Please try again.</div>";
                }
            } else {
                echo "<div class='error'>No account found with that email.</div>";
            }
        }
        ?>
        <form action="index.php" method="post">
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" class="btn-login">Login</button>
        </form>
        <p class="login-footer">Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</div>
