<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Suggestion</title>
    <link rel="stylesheet" href="assets/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body, h1, h2, h3, p {
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #3e8ef7, #7fbcf7);
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        header {
            background-color: #ffffff;
            width: 100%;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        header h1 {
            color: #3e8ef7;
        }

        .navbar {
            background-color: #3e8ef7;
            width: 100%;
            display: flex;
            justify-content: center;
            padding: 15px 0;
        }

        .navbar ul {
            list-style: none;
            display: flex;
            gap: 20px;
            padding: 0;
            margin: 0;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            font-size: 17px;
            padding: 10px 20px;
            border-radius: 8px;
            transition: background-color 0.3s;
        }

        .navbar a:hover {
            background-color: #357bd1;
        }

        .container {
            background-color: #fff;
            width: 90%;
            max-width: 600px;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            margin-top: 30px;
            text-align: center;
        }

        .container h2 {
            color: #3e8ef7;
        }

        textarea, select, button {
            width: 100%;
            margin-top: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #3e8ef7;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #357bd1;
        }

        textarea {
            resize: none;
        }

        .message {
            margin-top: 15px;
            color: green;
        }
    </style>
</head>
<body>
    <header>
        <h1>Submit Your Suggestion</h1>
    </header>

    <nav class="navbar">
        <ul>
                     <li><a href="./home.php">Home</a></li>
            <li><a href="feedback.php">Feedback</a></li>
            <li><a href="issues.php">Report An Issue</a></li>
            <li><a href="reported_issue.php">Complaints</a></li>
            <li><a href="suggestions.php">Polls</a></li>
            <li><a href="projects.php">Projects</a></li>
            <li><a href="https://meet.google.com/">Town Halls</a></li>
        </ul>
     
    </nav>

    <div class="container">
        <h2>Welcome to the Citizen Participation Platform</h2>
        <p>Engage with your community, share feedback, vote on policies, and track local projects.</p>
        <a href="suggestions.php" class="button">View Suggestions</a>
    </div>

    <div class="container">
        <?php
        include 'db_connection.php';
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $user_id = 1; // Replace this with the session user's ID
            $title = $conn->real_escape_string($_POST['title']);
            $description = $conn->real_escape_string($_POST['description']);

            $query = "INSERT INTO feedback (user_id, title, description) VALUES ('$user_id', '$title', '$description')";
            if ($conn->query($query)) {
                echo "<div class='message'>Suggestion submitted successfully!</div>";
            } else {
                echo "<div class='message' style='color: red;'>Error: " . $conn->error . "</div>";
            }
        }
        ?>

        <form action="feedback.php" method="post">
            <select name="title" id="project_title" required>
                <option value="" disabled selected>Choose a project</option>
                <?php
                // Include database connection

                // Query to fetch project titles
                $query = "SELECT project_id, title FROM projects ORDER BY title ASC";
                $result = $conn->query($query);

                // Populate the dropdown
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['project_id'] . "'>" . htmlspecialchars($row['title']) . "</option>";
                    }
                } else {
                    echo "<option value='' disabled>No projects available</option>";
                }
                ?>
            </select>
            <textarea name="description" placeholder="Describe your suggestion" rows="5" required></textarea>
            <button type="submit">Submit Suggestion</button>
        </form>
    </div>
</body>
</html>
