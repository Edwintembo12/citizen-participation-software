<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $suggestion_id = intval($_POST['suggestion_id']);
    $vote = $_POST['vote'];

    if ($vote == 'upvote') {
        $query = "UPDATE feedback SET upvotes = upvotes + 1 WHERE suggestion_id = '$suggestion_id'";
    } elseif ($vote == 'downvote') {
        $query = "UPDATE feedback SET downvotes = downvotes + 1 WHERE suggestion_id = '$suggestion_id'";
    }

    if ($conn->query($query)) {
        header('Location: suggestions.php');
    } else {
        echo "Error: " . $conn->error;
    }
}
$conn->close();
?>
