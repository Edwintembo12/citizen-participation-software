<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Projects</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Roboto', sans-serif;
            background-color: #f5f7fa;
            color: #333;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px;
            background-color: #3e8ef7;
            color: #fff;
        }

        header .logo {
            display: flex;
            align-items: center;
        }

        header .logo img {
            height: 40px;
            margin-right: 15px;
        }

        header .logo h1 {
            margin: 0;
            font-size: 24px;
        }

        .navbar {
            background-color: #357bd1;
            padding: 10px 20px;
        }

        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: space-around;
        }

        .navbar ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: 500;
            padding: 8px 15px;
            transition: background-color 0.3s;
        }

        .navbar ul li a:hover {
            background-color: #285ba1;
            border-radius: 5px;
        }

        .container {
            max-width: 1200px;
            margin: 30px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 16px;
            margin-top: 20px;
        }

        table thead {
            background-color: #3e8ef7;
            color: #fff;
        }

        table th, table td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
        }

        table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tbody tr:hover {
            background-color: #eaf4ff;
        }

        table tbody tr td.status {
            font-weight: bold;
            text-align: center;
            border-radius: 5px;
            color: #fff;
        }

        table tbody tr td.status.Upcoming {
            background-color: #ffeaa7;
            color: #333;
        }

        table tbody tr td.status.Ongoing {
            background-color: #74b9ff;
        }

        table tbody tr td.status.Completed {
            background-color: #55efc4;
        }

        @media (max-width: 768px) {
            .navbar ul {
                flex-direction: column;
                align-items: center;
            }

            table {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="assets/logo.png" alt="Logo">
            <h1>Citizen Participation</h1>
        </div>
        <div class="nav-toggle">☰</div>
    </header>

 
    <nav class="navbar">
        <ul>
                     <li><a href="./home.php">Home</a></li>
            <li><a href="feedback.php">Feedback</a></li>
            <li><a href="issues.php">Report An Issue</a></li>
            <li><a href="reported_issue.php">Complaints</a></li>
            <li><a href="suggestions.php">Polls</a></li>
            <li><a href="projects.php">Projects</a></li>
            <li><a href="https://meet.google.com/">Town Halls</a></li>
        </ul>
     
    </nav>

    <div class="container">
        <h2>Project Overview</h2>
        <table>
            <thead>
                <tr>
                    <th>Project ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Created By</th>
                </tr>
            </thead>
            <tbody>
            <?php
include 'db_connection.php';

// Check if the user is an admin

$query = "SELECT * FROM projects ORDER BY start_date DESC";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['project_id']}</td>
                <td>{$row['title']}</td>
                <td>{$row['description']}</td>
                <td>{$row['start_date']}</td>
                <td>{$row['end_date']}</td>
             
              <td>{$row['created_by']}</td>
            </tr>";
    }
} else {
    echo "<tr><td colspan='7'>No projects found.</td></tr>";
}

$conn->close();
?>

            </tbody>
        </table>
    </div>
</body>
</html>
