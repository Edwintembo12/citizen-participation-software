<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Public Issue</title>
    <link rel="stylesheet" href="assets/styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        header {
            background: #3e8ef7;
            color: #fff;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo h1 {
            margin: 0;
            font-size: 1.5rem;
        }

        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            background: #333;
        }

        .navbar ul li {
            margin: 0;
        }

        .navbar ul li a {
            color: #fff;
            padding: 10px 20px;
            display: block;
            text-decoration: none;
        }

        .navbar ul li a:hover {
            background: #4CAF50;
        }

        .container {
            max-width: 800px;
            margin: 30px auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .container h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }

        .form-group textarea {
            resize: none;
        }

        .button {
            display: block;
            width: 100%;
            background: #4CAF50;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 1.1rem;
            cursor: pointer;
            text-align: center;
            margin-top: 10px;
        }

        .button:hover {
            background: #45a049;
        }

        @media (max-width: 600px) {
            header {
                flex-direction: column;
                text-align: center;
            }

            .navbar ul {
                flex-direction: column;
            }

            .navbar ul li a {
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <h1>Citizen Participation</h1>
        </div>
        <div class="nav-toggle" onclick="toggleMenu()">☰</div>
    </header>

 
    <nav class="navbar">
        <ul>
                     <li><a href="./home.php">Home</a></li>
            <li><a href="feedback.php">Feedback</a></li>
            <li><a href="issues.php">Report An Issue</a></li>
            <li><a href="reported_issue.php">Complaints</a></li>
            <li><a href="suggestions.php">Polls</a></li>
            <li><a href="projects.php">Projects</a></li>
            <li><a href="https://meet.google.com/">Town Halls</a></li>
        </ul>
     
    </nav>
    <main>
        <div class="container">
            <h2>Report a Public Issue</h2>
            <?php
// Database connection
include 'db_connection.php'; // Ensure this file contains the proper database connection code

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate inputs
    $issue_id = mysqli_real_escape_string($conn, $_POST['issue_id']);
    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
    $issue_title = mysqli_real_escape_string($conn, $_POST['issue_title']);
    $issue_description = mysqli_real_escape_string($conn, $_POST['issue_description']);
    $report_date = mysqli_real_escape_string($conn, $_POST['report_date']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Check if required fields are empty
    if (empty($issue_id) || empty($user_id) || empty($issue_title) || empty($issue_description) || empty($report_date) || empty($status)) {
        die("All fields are required. Please go back and complete the form.");
    }

    // Prepare the SQL query
    $sql = "INSERT INTO publicissues (issue_id, user_id, issue_title, issue_description, report_date, status) 
            VALUES ('$issue_id', '$user_id', '$issue_title', '$issue_description', '$report_date', '$status')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Issue reported successfully!'); window.location.href = 'reported_issue.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.history.back();</script>";
    }

    // Close the database connection
} else {
}
?>

            <form action="issues.php" method="POST" class="issue-form">
                <div class="form-group">
                    <label for="issue_id">Issue ID</label>
                    <input type="text" id="issue_id" name="issue_id" placeholder="Enter issue ID" required>
                </div>
                <div class="form-group">
                    <label for="user_id">User ID</label>
                    <input type="text" id="user_id" name="user_id" placeholder="Enter user ID" required>
                </div>
                <div class="form-group">
                    <label for="issue_title">Issue Title</label>
                    <input type="text" id="issue_title" name="issue_title" placeholder="Enter issue title" required>
                </div>
                <div class="form-group">
                    <label for="issue_description">Issue Description</label>
                    <textarea id="issue_description" name="issue_description" placeholder="Describe the issue" rows="5" required></textarea>
                </div>
                <div class="form-group">
                    <label for="report_date">Report Date</label>
                    <input type="date" id="report_date" name="report_date" required>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status" required>
                        <option value="Pending">Pending</option>
                        <option value="Resolved">Resolved</option>
                        <option value="In Progress">In Progress</option>
                    </select>
                </div>
                <button type="submit" class="button">Submit Issue</button>
            </form>
        </div>
    </main>
</body>
</html>
